import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import datetime
import yfinance as yf
import matplotlib.dates as mdates
import json
from sklearn.preprocessing import MinMaxScaler
import keras
import tensorflow as tf
from keras.models import Sequential
from keras.layers import Dense, SimpleRNN, Dropout
from keras.callbacks import EarlyStopping
from flask import Flask, render_template
from flask_restful import Api, Resource
from flask import Flask, render_template, request, jsonify,g 

app = Flask(__name__,static_folder='static')
api =   Api(app)

stocks = ['AAPL', 'WMT', 'MSFT', 'AMZN']
@app.route('/about')
def about():
    return render_template('dashboard.html')

@app.route("/",methods=["POST","GET"])
def index():
    if request.method == "POST":
        stocks = request.form.get("stocks")
    return render_template('index.html')

@app.route('/get_close_prices', methods=['GET'])
def get_initial_data():
    global initial_data
    # Check if initial_data has already been fetched
    if 'initial_data' not in g:
        start_date = datetime.datetime.now() - pd.DateOffset(years=1)
        end_date = datetime.datetime.now()
        stock_data_dict = {}
        for stock in stocks:
            stock_data = get_stock_data(stock, start_date, end_date)
            stock_data_dict[stock] = stock_data
        initial_data = []
        for stock, stock_data_df in stock_data_dict.items():
            close_prices = [round(price, 3) for price in stock_data_df['Close'].tolist()]
            dates = stock_data_df.index.strftime('%Y-%m-%d').tolist()
            initial_data.append({'stock': stock, 'close_prices': close_prices, 'dates': dates})
        # Store the initial data in the global variable
        g.initial_data = initial_data
    return jsonify(g.initial_data)

@app.route('/predict_stocks', methods=['GET'])
def predict_stocks():
    stock_param = request.args.get('stock')
    start_date = datetime.datetime.now() - pd.DateOffset(years=10)
    end_date = datetime.datetime.now()
    stocks_to_predict =[]
    stocks_to_predict.append(stock_param)
    stock_data_dict = {}
    predictions = {}
    predicted_data=[]
    for stock in stocks_to_predict:
        stock_data = get_stock_data(stock, start_date, end_date)
        stock_data_dict[stock] = stock_data
    
    for stock, stock_data_df in stock_data_dict.items():
        stockdata_final_df = preprocess_stock_data(stock_data_df)
        stockdata_train, stockdata_test = split_data(stockdata_final_df)
        scaler = MinMaxScaler(feature_range=(0, 1))
        stocktrain_scaled = scaler.fit_transform(stockdata_train)
        stocktest_scaled = scaler.transform(stockdata_test)
        X_train, y_train = create_sequences(stocktrain_scaled)
        model = build_rnn_model(X_train.shape)
        history = train_rnn_model(model, X_train, y_train)
        X_test, y_test = create_sequences(stocktest_scaled)
        y_pred, y_train = predict_stock_prices(model, X_test, scaler, y_train)
        predictions[stock] = {'y_pred': y_pred.tolist(), 'y_train': y_train.tolist()}
        result_json = json.dumps(predictions, indent=2)
        y_train_flat = [value[0] for value in y_train]
        predicted_data.append({'stock':stock,'y_pred': y_pred.tolist(), 'y_train': [value[0] for value in y_train]})
    return jsonify(predicted_data)
        
def get_stock_data(ticker, start_date, end_date):
    stock_data = yf.download(ticker, start=start_date, end=end_date)
    return stock_data

def preprocess_stock_data(stockdata_df):
    stockdata_df.drop('Volume', axis=1, inplace=True)
    stockdata_final_df = pd.DataFrame(stockdata_df['Close'].copy())
    return stockdata_final_df

def split_data(stockdata_final_df, test_size=0.3):
    train_datasize = round(len(stockdata_final_df) * (1 - test_size))
    test_datasize = len(stockdata_final_df) - train_datasize
    stock_traindf = stockdata_final_df.iloc[:train_datasize, :]
    stockdata_train = stock_traindf.values
    stock_testdf = stockdata_final_df.iloc[train_datasize:, :]
    stockdata_test = stock_testdf.values
    return stockdata_train, stockdata_test

def scale_stock_data(stockdata_train, stockdata_test):
    scaler = MinMaxScaler(feature_range=(0, 1))
    stocktrain_scaled = scaler.fit_transform(stockdata_train)
    stocktest_scaled = scaler.transform(stockdata_test)
    return stocktrain_scaled, stocktest_scaled

def create_sequences(stocktrain_scaled, days_steps=30):
    X_train, y_train = [], []
    for i in range(days_steps, len(stocktrain_scaled)):
        X_train.append(stocktrain_scaled[i - days_steps: i, 0])
        y_train.append(stocktrain_scaled[i, 0])
    X_train, y_train = np.array(X_train), np.array(y_train)
    X_train = np.reshape(X_train, (X_train.shape[0], X_train.shape[1], 1))
    y_train = np.reshape(y_train, (-1, 1))
    return X_train, y_train

def build_rnn_model(X_train_shape):
    es = EarlyStopping(monitor='loss')
    model = Sequential()
    model.add(SimpleRNN(units=50, return_sequences=True, activation='tanh', input_shape=X_train_shape[1:]))
    model.add(Dropout(0.2))
    model.add(SimpleRNN(units=50, return_sequences=True, activation='tanh'))
    model.add(Dropout(0.2))
    model.add(SimpleRNN(units=50))
    model.add(Dropout(0.2))
    model.add(Dense(units=1))
    model.compile(optimizer='adam', loss='mean_squared_error', metrics=['accuracy'])
    return model

def train_rnn_model(model, X_train, y_train, epochs=100, batch_size=32):
    history = model.fit(X_train, y_train, epochs=epochs, batch_size=batch_size)
    return history


def predict_stock_prices(model, X_train, scaler, y_train):
    y_pred = model.predict(X_train)
    y_pred = scaler.inverse_transform(y_pred.reshape(1,-1))
    y_train = scaler.inverse_transform(y_train.reshape(-1, 1))
    return y_pred, y_train

if __name__ == "__main__":
    app.run(debug=True)